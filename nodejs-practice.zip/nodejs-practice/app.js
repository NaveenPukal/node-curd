var createError = require("http-errors");
var express = require("express");
var path = require("path");
var cookieParser = require("cookie-parser");
var logger = require("morgan");

var indexRouter = require("./routes/index");
var usersRouter = require("./routes/users");
var nodemailer = require("nodemailer");
var db = require("./db/config");

var app = express();

var bodyParser = require("body-parser");
app.use(bodyParser.urlencoded({ extended: true }));

app.get("/home", (req, res, next) => {
  res.sendFile(path.join(__dirname, "./public/form.html"));
});

//email

app.use("/email", (req, res) => {
  res.send("hai");
});

var transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: "pukalnaveen98@gmail.com",
    pass: "Naveen@1998",
  },
});

var mailOptions = {
  from: "pukalnaveen98@gmail.com",
  to: "pukalnaveen98@gmail.com",
  subject: "This is from nodejs application",
  text: "Hello nagapandian, How is going your BookMyShow application",
};

transporter.sendMail(mailOptions, function (error, info) {
  if (error) {
    console.log(error);
  } else {
    console.log("Email sent: " + info.response);
  }
});

// Insert

app.post("/add", function (req, res) {
  const empDetails = req.body;
  var sql = "insert into emp set?";
  db.query(sql, empDetails, function (err) {
    if (err) {
      return console.log(err.message);
    }
    console.log("New employee has been added");
    res.send(
      "New employee has been added into the database with ID = " +
        req.body.id +
        " and Name = " +
        req.body.name
    );
  });
});

//view all employees
/* app.post('/view',(req,res)=>{

  const empDetails = req.body
  var sql = 'select * from emp where id = ?'
  db.query(sql,empDetails,(err)=>{
    if(err){
      return console.log(err.message)
    }
    console.log('Display employee')
    res.send("Displaying employee by ID = "+req.body.id+ " and Name = "+req.body.name);
  })
}) */

//update

 app.post('/update',(req,res)=>{
  
  const empid = req.body.id
  const empDetail = req.body.name
  var sql = "update emp set name = ? where id = ?"
  db.query(sql,[empDetail,empid],(err)=>{
    if(err){
      return console.log(err.message)
    }
    console.log('Display employee')
    res.send("Employee name updated");
  })
  })

// app.get("/view", (req, res) => {
  
//   let sqlQuery = "SELECT * FROM emp WHERE id=?";

//   let query = db.query(sqlQuery,req.body.id,(err, results) => {
//     if (err) throw err;
//     res.send(results);
//   });
// });

// con.connect(function(err) {
//   if (err) throw err;
//   con.query("SELECT * FROM customers", function (err, result, fields) {
//     if (err) throw err;
//     console.log(result);
//   });
// });

//view employee by id

 app.get('/view', (req, res) => {

   const query ="select * from emp where id =?";
   const val=req.body.id;
  db.query(query,val,function(err,result){

    if(err){
      return console.log(err.message)
    }
    // console.log('Display employee')
    res.send(req);
   });
});




//delete list in tables
app.post("/delete", (req, res) => {
  const empDetails = req.body.id;
  var sql = "delete from emp where id = ?";
  db.query(sql, empDetails, (err) => {
    if (err) {
      return console.log(err.message);
    }
    console.log("Deleted All Employees");
    res.send("Given id deleted");
  });
});

//delete all in tables
app.post("/deleteAll", (req, res) => {
  const empDetail = req.body;
  var sql = "delete from emp";
  db.query(sql, empDetail, (err) => {
    if (err) {
      return console.log(err.message);
    }
    console.log("Deleted All Employees");
    res.send("All employees deleted");
  });
});

// view engine setup
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "jade");

app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public"))); //for implementing styles(css)

app.use("/", indexRouter);
app.use("/users", usersRouter);

//catch 404 and forward to error handler
app.use(function (req, res, next) {
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get("env") === "development" ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render("error");
});

app.listen(3030, function () {
  console.log("server is listening on port: 3030");
});
