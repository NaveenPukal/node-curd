// var express = require('express')
// var nodemailer = require('nodemailer')
// var app = express()

// app.use('/email',(req,res)=>{
//     res.send('hai')
// })

// var transporter = nodemailer.createTransport({
//     service : 'gmail',
//     auth:{
//         user : 'pukalnaveen98@gmail.com',
//         pass : 'Naveen@1998'
//     }
// })

// var mailOptions = {
//     from: 'pukalnaveen98@gmail.com',
//     to : 'nagapandian619@gmail.com',
//     subject : 'This is from nodejs application',
//     text : 'Hello nagapandian, How is going your BookMyShow application'
// }

// transporter.sendMail(mailOptions, function(error,info){
//     if(error){
//         console.log(error)
//     }
//     else{
//         console.log('Email sent: '+info.response)
//     }
// })

// app.listen(5011)